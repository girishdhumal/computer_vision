from inltk.inltk import tokenize 
hindi_text = """प्राकृ तिक भाषा सीखना बहुत तिलचस्प है।""" 
# tokenize(input text, language code) 
tokenize(hindi_text, "hi")
