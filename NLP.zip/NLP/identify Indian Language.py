from inltk.inltk import setup 
setup('gu')
from inltk.inltk import identify_language 
#Identify the Lnaguage of given text 
identify_language('બીના કાપડિ યા')
