import gensim 
from gensim.utils import tokenize 
#from gensim.utils import tokenize 
str = "I love to study Natural Language Processing in Python" 
# tokenizing the text 
list(tokenize(str))
