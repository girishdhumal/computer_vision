thisdict = { "brand": "Ford",
"model": "Mustang", "year": 1964
}


print(thisdict)
print(thisdict["brand"])
print(len(thisdict))
print(type(thisdict))
